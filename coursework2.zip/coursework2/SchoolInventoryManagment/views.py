from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return HttpResponse("<h1>Home Page</h1>")

def blist(request):
    return HttpResponse("<h1>Ho Page</h1>")

def navbar(request):
  return render(request, 'navbar.html')