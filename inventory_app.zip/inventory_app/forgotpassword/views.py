#this file was done by Aiman Ume Id:w1940531


from django.contrib.auth import get_user_model, login
from django.contrib.auth.forms import SetPasswordForm
from django.shortcuts import render, redirect
from django.urls import reverse
from django.http import  HttpResponseRedirect

def forgotpassword_view(request):
    if request.method == 'POST':
        form = SetPasswordForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  
    else:
        form = SetPasswordForm(user=request.user)
    return render(request, 'forgotpassword.html', {'form': form})

