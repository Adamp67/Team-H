from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from main.models import UserProfile, Equipment
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.core.serializers import serialize
import datetime



# Create your views here.

@login_required(login_url="main:signup")
def index(request):
    return render(request, "index.html")

def handleLogin(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        user = authenticate(username=email, password=password)
        if user:
            login(request, user)
            return redirect("main:index")
    return render(request, "student_login.html")

def handleSignup(request):
    if request.method == "POST":
        fullname = request.POST.get("full-name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        first_name = fullname.split(" ")[0]
        if len(fullname.split(" ")) > 1:
            last_name = fullname.split(" ")[1]
        else:
            last_name = ""
        # check is user exists
        if User.objects.filter(email=email).exists():
            # messages.error(request, "Email already exists")
            return render(request, "signup.html", {"error": "Email already exists"})
        else:
            user = User.objects.create_user(username=email, email=email, password=password, first_name=first_name, last_name=last_name)
            user.save()
            UserProfile.objects.create(user=user)
            user = authenticate(username=email, password=password)
            login(request, user)

            # messages.success(request, "Account created successfully")
            return redirect("profile")
        
    return render(request, "signup.html")


def handleLogout(request):
    logout(request)
    return redirect("main:signup")

@login_required
def useraccounts(request):
    try:
        user = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        user = None  # Or handle the error as appropriate
  
    return render(request, "user-accounts.html", {"user": user})

def updateprofile(request):
    if request.method == "POST":
        user = UserProfile.objects.get(user=request.user)
        user.user.first_name = request.POST.get("first-name")
        user.user.last_name = request.POST.get("last-name")
        user.user.email = request.POST.get("email")
        if request.POST.get("admin-user") == "on":
            user.role = "Admin User"
        else:
            user.role = "Regular User"
        user.save()
        user.user.save()
        messages.success(request, "Profile updated successfully")
        return redirect("main:user-accounts")
    return render(request, "update-profile.html")

def equipmentList(request):
    equipments = Equipment.objects.all()
    context = {
        "equipments": equipments,
    }
    return render(request, "equipment-list.html", context)

def addEquipment(request):
    if request.method == "POST":
        name = request.POST.get("device-name")
        device_type = request.POST.get("device-type")
        quantity = request.POST.get("quantity")
        audit = request.POST.get("audit")
        location = request.POST.get("location")
        equipment = Equipment.objects.create(name=name, device_type=device_type, quantity=quantity, audit_date=audit, location=location)
        equipment.save()

        return redirect("main:equipment-list")

def deleteEquipment(request, id):
    equipment = Equipment.objects.get(id=id)
    equipment.delete()
    return redirect("main:equipment-list")

def editEquipment(request, id):
    equipment = Equipment.objects.get(id=id)
    equipment_json = serialize('json', [equipment])
    print(equipment_json)
    return JsonResponse(equipment_json, safe=False)

def updateEquipment(request):
    if request.method == "POST":
        id = request.POST.get("id")
        equipment = Equipment.objects.get(id=id)
        equipment.name = request.POST.get("device-name")
        equipment.device_type = request.POST.get("device-type")
        equipment.quantity = request.POST.get("quantity")
        equipment.audit_date = request.POST.get("audit")
        equipment.location = request.POST.get("location")
        equipment.save()
        return redirect("main:equipment-list")
    return render(request, "edit-equipment.html")


data = [
 {
  "Device Name": "Laptop w\/ 2070 GPU",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "2022-05-20",
  "Location": "Other",
  "Status": "On_loan"
 },
 {
  "Device Name": "Laptop w\/ 2070",
  "Device Type": "PC\/Laptop",
  "Quantity": 3,
  "Audit": "2023-03-24",
  "Location": "XRLab Blue Cabinet",
  "Status": "Repairing"
 },
 {
  "Device Name": "Valve Index",
  "Device Type": "VR Headset",
  "Quantity": 3,
  "Audit": "2022-04-14",
  "Location": "XRLab",
  "Status": "Available"
 },
 {
  "Device Name": "Vive Pro Eye",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Base Station 2",
  "Device Type": "Camera\/Sensors",
  "Quantity": 6,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "PC w\/ 1080",
  "Device Type": "PC\/Laptop",
  "Quantity": 4,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "PC w\/ 1060",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Windows AIO PC",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab",
  "Status": "Decommisioned "
 },
 {
  "Device Name": "Mac Mini (Intel)",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet",
  "Status": "Repairing",
  "Comments": "Repurpose into linux project pc"
 },
 {
  "Device Name": "HP Omen Ultrawide ",
  "Device Type": "PC Peripherals",
  "Quantity": 4,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Monitor 16:9 ",
  "Device Type": "PC Peripherals",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Keyboard",
  "Device Type": "PC Peripherals",
  "Quantity": 7,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Mouse",
  "Device Type": "PC Peripherals",
  "Quantity": 7,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Samsung smart TV 55 Inch",
  "Device Type": "PC Peripherals",
  "Quantity": 3,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Movable TVs ",
  "Device Type": "PC Peripherals",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Clevertouch Screen",
  "Device Type": "PC Peripherals",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Desk",
  "Device Type": "Furniture",
  "Quantity": 5,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Lectern",
  "Device Type": "Furniture",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Chair ",
  "Device Type": "Furniture",
  "Quantity": 6,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Chair w\/ Armrest",
  "Device Type": "Furniture",
  "Quantity": 5,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Stool",
  "Device Type": "Furniture",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Table",
  "Device Type": "Furniture",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Chair w\/o backrest",
  "Device Type": "Furniture",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Leap motion Mount",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "VRGo Egg Chair",
  "Device Type": "PC Peripherals",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Generic Tripod",
  "Device Type": "Tripod",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Manfroto Tripod",
  "Device Type": "Tripod",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Green screen",
  "Device Type": "Other",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab"
 },
 {
  "Device Name": "Linx Vision Gaming Tablet",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet",
  "Comments": "only runs 32bit OS and super low specs (end of life) "
 },
 {
  "Device Name": "Insta 360 Pro",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large"
 },
 {
  "Device Name": "Insta 360 Pro 2",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large"
 },
 {
  "Device Name": "Samsung Gear 360 Camera",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet",
  "Comments": "Remove if S6 is decommisioned"
 },
 {
  "Device Name": "Insta 360 Pro Battery",
  "Device Type": "Power\/Cable",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Insta 360 Pro Charger x 1",
  "Device Type": "Power\/Cable",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Structure sensor",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Leap Motion",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Leap Motion",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-05-20",
  "Location": "Other"
 },
 {
  "Device Name": "Laptop w\/ 1070",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "2022-05-20",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Pico 4",
  "Device Type": "VR Headset",
  "Quantity": 2,
  "Audit": "2023-09-18",
  "Location": "XRLab Blue Cabinet Large"
 },
 {
  "Device Name": "Pico 4 Enterprise",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "2023-09-18",
  "Location": "XRLab Blue Cabinet Large"
 },
 {
  "Device Name": "Oculus Quest w\/ Controllers",
  "Device Type": "VR Headset",
  "Quantity": 3,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large"
 },
 {
  "Device Name": "Hololens 1",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large",
  "Comments": "Need repairs"
 },
 {
  "Device Name": "Hololens 2",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large",
  "Comments": "Need repairs"
 },
 {
  "Device Name": "Vive Pro Controller Pair",
  "Device Type": "VR Controller",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Valve Knuckles Controller Pair",
  "Device Type": "VR Controller",
  "Quantity": 3,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Emotiv EEG",
  "Device Type": "Other",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet",
  "Comments": "Broken and never used (spare parts no longer available)"
 },
 {
  "Device Name": "Neewer 480 LED Lights",
  "Device Type": "Other",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "BeBox Router",
  "Device Type": "Other",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet",
  "Comments": "Decommision if we replace it with 5ghz router for wireless VR"
 },
 {
  "Device Name": "Generic Tripod",
  "Device Type": "Tripod",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "GearVR Headset",
  "Device Type": "VR Headset",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "GearVR Controller",
  "Device Type": "VR Controller",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "IPad Air Gen3 2019",
  "Device Type": "Phones\/Tablets",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Anker 10 port USB charger",
  "Device Type": "Power\/Cable",
  "Quantity": 3,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Anker Power Bank 10000MAH",
  "Device Type": "Power\/Cable",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "HTC Power Bank 5700MAH",
  "Device Type": "Power\/Cable",
  "Quantity": 2,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Vive Wireless Adapter",
  "Device Type": "Other",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Vive Trackers & Dongles",
  "Device Type": "VR Controller",
  "Quantity": 4,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Samsung Galaxy S6",
  "Device Type": "Phones\/Tablets",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet",
  "Comments": "End of life and only used for gearVR\/360"
 },
 {
  "Device Name": "Google Pixel 2",
  "Device Type": "Phones\/Tablets",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet",
  "Comments": "Authenticators on this phone"
 },
 {
  "Device Name": "Xbox One Controller ",
  "Device Type": "PC Peripherals",
  "Quantity": 5,
  "Audit": "2022-04-14",
  "Location": "XRLab Medium Wooden Cabinet"
 },
 {
  "Device Name": "Xbox One Dongle",
  "Device Type": "PC Peripherals",
  "Quantity": 5,
  "Audit": "2022-04-14",
  "Location": "XRLab Medium Wooden Cabinet"
 },
 {
  "Device Name": "Xbox 360 Controller",
  "Device Type": "PC Peripherals",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Medium Wooden Cabinet"
 },
 {
  "Device Name": "Kinect 1",
  "Device Type": "Camera\/Sensors",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Medium Wooden Cabinet"
 },
 {
  "Device Name": "Keyboard",
  "Device Type": "PC Peripherals",
  "Quantity": 5,
  "Audit": "2022-04-14",
  "Location": "XRLab Medium Wooden Cabinet"
 },
 {
  "Device Name": "Mouse",
  "Device Type": "PC Peripherals",
  "Quantity": 5,
  "Audit": "2022-04-14",
  "Location": "XRLab Medium Wooden Cabinet"
 },
 {
  "Device Name": "OSVR Dev Kit",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Blue Cabinet Large",
  "Comments": "Severe end of life (website and documentation gone)"
 },
 {
  "Device Name": "Yost Labs PrioVR",
  "Device Type": "Other",
  "Quantity": 1,
  "Audit": "2022-04-14",
  "Location": "XRLab Medium Wooden Cabinet"
 },
 {
  "Device Name": "Wacom Intuos Small",
  "Device Type": "PC Peripherals",
  "Quantity": 1,
  "Audit": "2023-02-24",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Wacom Intuos",
  "Device Type": "PC Peripherals",
  "Quantity": 1,
  "Audit": "2023-04-04",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "Oculus Rift w\/ Controller Pair",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large",
  "Comments": "Only used for external events and barely functions"
 },
 {
  "Device Name": "Oculus Quest 2 w\/ Controller Pair",
  "Device Type": "VR Headset",
  "Quantity": 2,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large"
 },
 {
  "Device Name": "Vive Focus 3 w\/ Controller Pair",
  "Device Type": "VR Headset",
  "Quantity": 5,
  "Audit": "2022-09-22",
  "Location": "XRLab Blue Cabinet Large"
 },
 {
  "Device Name": "Oculus Quest 2 w\/ Controller Pair",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "2023-03-24",
  "Location": "Other"
 },
 {
  "Device Name": "Vive 2 ",
  "Device Type": "VR Headset",
  "Quantity": 1,
  "Audit": "09\/18\/2023",
  "Location": "XRLab"
 },
 {
  "Device Name": "USB C 3.2 Expansion cards x3",
  "Device Type": "Other",
  "Quantity": 3,
  "Audit": "10\/19\/2023",
  "Location": "XRLab",
  "Comments": "In index workstation 1,2 & 3"
 },
 {
  "Device Name": "Mac Mini (Intel)",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "10\/19\/2023",
  "Location": "XRLab"
 },
 {
  "Device Name": "Raspberry pi 4",
  "Device Type": "PC\/Laptop",
  "Quantity": 1,
  "Audit": "19-Oct",
  "Location": "XRLab Blue Cabinet",
  "Comments": "Frequently used in other parts of lab"
 },
 {
  "Device Name": "iPad pro gen6",
  "Device Type": "Phones\/Tablets",
  "Quantity": 1,
  "Audit": "10\/19\/2023",
  "Location": "XRLab Blue Cabinet"
 },
 {
  "Device Name": "vive tracker 2",
  "Device Type": "VR Controller",
  "Quantity": 5,
  "Audit": "10\/19\/2023",
  "Location": "XRLab Blue Cabinet Large"
 }
]

def automate(request):
    for item in data:
        # fix the audit date
        try:
            date = item["Audit"].split("-")
            audit_date = datetime.datetime(int(date[0]), int(date[1]), int(date[2]))
        except:
            try:
                date = item["Audit"].split("-")
                audit_date = datetime.datetime(int(date[2]), int(date[0]), int(date[1]))
            except:
                pass
            
        equipment = Equipment.objects.create(name=item["Device Name"], device_type=item["Device Type"], quantity=item["Quantity"], audit_date=audit_date, location=item["Location"])
        equipment.save()

    return HttpResponse("Automate page")