from django.contrib import admin
from .models import UserProfile, Equipment
# Register your models here.
admin.site.register(UserProfile)
admin.site.register(Equipment)