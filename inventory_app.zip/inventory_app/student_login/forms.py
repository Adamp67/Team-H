#this file was done by Aiman Ume Id:w1940531

from string import punctuation
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.core.exceptions import ValidationError

class StudentLoginForm(AuthenticationForm):
    def clean_email(self):
        email = self.cleaned_data.get('email')
        # Add your email validation logic here
        return email

    def clean_password(self):
        password = self.cleaned_data.get('password')
        return password