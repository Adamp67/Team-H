#this file was done by Aiman Ume Id:w1940531

from django.shortcuts import render

from appone.models import Equipment

# Create your views here.
def accesspoint_view(request):
    return render(request, 'accesspoint.html')


def equipment_list(request):
    equipments = Equipment.objects.all()  # Retrieves all equipment from the database
    return render(request, 'inventory/equipment_list.html', {'equipments': equipments})