from django.db import models



class Equipment(models.Model):
    name = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    quantity = models.IntegerField()
    audit_date = models.DateField()
    location = models.CharField(max_length=255)
    status = models.CharField(max_length=255, blank=True, null=True)
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name