#this file was done by Aiman Ume Id:w1940531

import email
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect


def admin_login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)

        if user is not None:
            if user.is_active and user.is_staff:
                login(request, user)
                return redirect('admin_homepage')
            else:
                return render(request, 'admin_login.html', {'error': 'Account is not active or not staff.'})
        else:
            return render(request, 'admin_login.html', {'error': 'Invalid credentials.'})
    else:
        return render(request, 'admin_login.html')