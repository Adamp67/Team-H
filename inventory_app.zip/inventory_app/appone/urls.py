from django.urls import path
from .import views
from .views import UserBooking, historical_booking,  home_view, reports, inventory, Checkout, CheckoutA, AdminBooking,  cancel_booking, check_login, return_booking

app_name = 'appone'

urlpatterns = [
    path('studenthomepage/', views.studenthomepage, name='studenthomepage'),
    path('equipment/', views.equipment, name='equipment'),
    path('reports/', views.reports, name='reports'),
    path('inventory/', inventory, name='inventory'),
    path('reports/', reports, name='reports'),
    path('Checkout/', Checkout, name='Checkout'),
    path('CheckoutA/', CheckoutA, name='CheckoutA'),
    path('user-booking/', UserBooking, name='UserBooking'),
    path('AdminBooking/', AdminBooking, name='AdminBooking'),
    path('UserRegistration/', views.UserRegistration, name='UserRegistration'),
    
    #fatima
    path('cancel-booking/<int:booking_id>/', cancel_booking, name='cancel_booking'),
    path('return-booking/<int:booking_id>/',return_booking, name='return_booking'),
    path('check_login/', check_login, name='check_login'),
    path('cancel_booking/<int:id>/', cancel_booking, name='cancel_booking'),
    path('cancel_booking/<int:booking_id>/', cancel_booking, name='cancel_booking'),
    

    #admin current_bookings 
    path('cancel_booking/<int:id>/', cancel_booking, name='cancel_booking'),
    path('historical_booking/', historical_booking, name='historical_booking'),
    path('home/', home_view, name='home'),
    path('cancel_booking/<int:booking_id>/', cancel_booking, name='cancel_booking'),
    path('', views.booking_home, name='home'),
    path('cancel_booking/<int:id>/', views.cancel_booking, name='cancel_booking'),
    path('view_details/<int:id>/', views.view_details, name='view_details'),
    path('cancel_booking/<int:id>/', cancel_booking, name='cancel_booking'),
]

