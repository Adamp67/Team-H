from django.db import models
from django.contrib.auth.models import User
from django.db import models
from django.conf import settings
from django.shortcuts import render

# Create your models here.

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=None, related_name='appone_profile')
    role = models.CharField(max_length=50, default="Regular User")
    def __str__(self):
        return self.user.username
    

    

class Equipment(models.Model):
  name = models.CharField(max_length=100)
  quantity = models.IntegerField()

class Booking(models.Model):
  student = models.ForeignKey(User, on_delete=models.CASCADE)
  equipment = models.ForeignKey(Equipment, on_delete=models.CASCADE)
  booking_date = models.DateField()
  return_date = models.DateField(null=True, blank=True)
  is_returned = models.BooleanField(default=False)







class Equipment(models.Model):
    DEVICE_TYPE_CHOICES = [
        ('PC_Laptop', 'PC/Laptop'),
        ('VR_Headset', 'VR Headset'),
        ('Camera_Sensors', 'Camera/Sensors'),
        ('PC_Peripherals', 'PC Peripherals'),
        ('Furniture', 'Furniture'),
        ('Other', 'Other'),
    ]
    name = models.CharField(max_length=100)
    device_type = models.CharField(max_length=20, choices=DEVICE_TYPE_CHOICES)
    quantity = models.IntegerField(default=1)
    location = models.CharField(max_length=100, blank=True)
    status = models.CharField(max_length=50, blank=True)  # Available, On Loan, Repairing, etc.
    comments = models.TextField(blank=True)

    def __str__(self):
        return self.name

class Booking(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    equipment = models.ForeignKey(Equipment, on_delete=models.CASCADE)
    booking_date = models.DateField()
    return_date = models.DateField()
    quantity = models.IntegerField(default=1)
    status = models.CharField(max_length=10, default='Active')  # Active, Cancelled
    study_task = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.equipment.name}"


        from django.shortcuts import render
from .models import Booking, Equipment

def home(request):
    user = request.user
    if user.is_authenticated:
        if user.is_staff:  # Assuming 'staff' status for admins
            current_bookings = Booking.objects.all()
            historical_bookings = Booking.objects.filter(status='Completed')
        else:
            current_bookings = Booking.objects.filter(user=user)
            historical_bookings = Booking.objects.filter(user=user, status='Completed')

        context = {
            'current_bookings': current_bookings,
            'historical_bookings': historical_bookings,
            'is_admin': user.is_staff
        }
        return render(request, 'appone/current_bookings.html', context)
    else:
        # Redirect or handle unauthenticated users
        return render(request, 'appone/login.html')  # Make sure to implement this or redirect as needed

