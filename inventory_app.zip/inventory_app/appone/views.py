from django.shortcuts import render
from django.contrib.auth import get_user_model
from django.http import JsonResponse
from rest_framework.decorators import api_view
from .models import  Booking
from .models import Equipment, Booking
from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash

from django.shortcuts import redirect, render
from .models import Booking
from django.http import JsonResponse

from django.shortcuts import render
from .models import Equipment

# Create your views here.

@login_required
def studenthomepage(request):
    return render(request, 'studenthomepage.html')
@login_required
def equipment(request):
    return render(request, 'equipment.html')
@login_required
def inventory(request):
    return render(request, 'inventory.html')
@login_required
def reports(request):
    return render(request, 'reports.html')
@login_required
def Checkout(request):
    return render(request, "Checkout.html")
@login_required
def CheckoutA(request):
    return render(request, "CheckoutA.html")
@login_required
def UserBooking(request):
    return render(request, "UserBooking.html")
@login_required
def AdminBooking(request):
    return render(request, "AdminBooking.html")
@login_required
def UserRegistration(request):
    return render(request, "UserRegistration.html")






@login_required
def current_bookings(request):
    return render(request, "home.html")
User = get_user_model()
@api_view(['PUT'])
def return_booking(request, booking_id):
    if request.method == 'PUT':
        try:
            booking = Booking.objects.get(id=booking_id)
            booking.is_returned = True
            booking.save()
            return JsonResponse({'message': 'Booking returned successfully'})
        except Booking.DoesNotExist:
            return JsonResponse({'error': 'Booking not found'}, status=404)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)

@api_view(['POST'])
def check_login(request):
    print("jsession", request.user)
    origin = request.headers.get('Origin')
    print("origin", origin)
    if request.user.is_authenticated:
        user_data = {
            'id': request.user.id,
            'username': request.user.username,
            'email': request.user.email
        }
        response = JsonResponse({'user': user_data})
        response['Access-Control-Allow-Origin'] = origin
        return response
    else:
        response = JsonResponse({'error': 'User is not logged in'}, status=401)
        response['Access-Control-Allow-Origin'] = origin
        return response









def booking_home(request):
    current_bookings = [
        {'name': 'Laptop', 'booking_date': '02/05/2024', 'return_date': '20/05/2024', 'id': 1},
        # Add more bookings as needed
    ]
    historical_bookings = [
        {'name': 'VR Headset', 'booking_date': '15/04/2024', 'return_date': '15/05/2024', 'status': 'Returned', 'id': 2},
        # Add more historical bookings as needed
    ]
    context = {
        'current_bookings': current_bookings,
        'historical_bookings': historical_bookings
    }
    return render(request, 'home.html', context)

   

def cancel_booking(request, id):
    # Add your logic here to cancel the booking with the given ID
    # For now, it simply redirects to the home page
    return redirect('student_homepage')

def view_details(request, id):
    # Add your logic here to retrieve the details for the booking with the given ID
    # For now, it renders a placeholder details page
    details = {}  # Replace with your logic to get details
    return render(request, 'details.html', {'details': details})



@login_required
def home_view(request):
    current_bookings = Booking.objects.filter(user=request.user, status='Active')
    historical_bookings = Booking.objects.filter(user=request.user, status='Cancelled')
    return render(request, "student_login.html", {
        'current_bookings': current_bookings,
        'historical_bookings': historical_bookings
    })

def equipment_list_view(request):
    equipments = Equipment.objects.all()  # Fetch all equipment from the database
    return render(request, 'inventory_app:equipment_list.html', {'equipments': equipments})

@login_required
def historical_booking(request):
    return render(request, 'historical_booking.html')