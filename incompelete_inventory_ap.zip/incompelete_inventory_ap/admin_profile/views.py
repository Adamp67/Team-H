from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import ProfileForm
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
@login_required
def adminprofile_view(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            user = form.save()
            # If password is changed, you need to handle re-authentication here
            if 'password' in form.cleaned_data:
                update_session_auth_hash(request, user)  # Keep the user logged in after password change
            messages.success(request, 'Your profile was updated.')
            return redirect('admin_profile')  # Redirect to the profile detail view
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = ProfileForm(instance=request.user)
    return render(request, 'adminprofile.html', {'form': form})