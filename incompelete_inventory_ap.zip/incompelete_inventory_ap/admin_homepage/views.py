#this file was done by Aiman Ume Id:w1940531

from django.shortcuts import render
from django.contrib.auth.decorators import login_required


# Create your views here.
@login_required
def admin_homepage_view(request):
   
    return render(request, 'admin_homepage.html')

    # Fetch data from the database as required
    active_users_count = User.objects.filter(approved=True).count()
    pending_approvals_count = User.objects.filter(approved=False).count()
    total_equipment_count = Equipment.objects.count()
    overdue_equipment_count = Equipment.objects.filter(overdue=True).count()

    return render(request, 'admin_homepage.html', {
        'active_users_count': active_users_count,
        'pending_approvals_count': pending_approvals_count,
        'total_equipment_count': total_equipment_count,
        'overdue_equipment_count': overdue_equipment_count,
    })
    

    