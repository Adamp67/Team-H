#this file was done by Aiman Ume Id:w1940531

from django.shortcuts import render

# Create your views here.
def accesspoint_view(request):
    return render(request, 'accesspoint.html')