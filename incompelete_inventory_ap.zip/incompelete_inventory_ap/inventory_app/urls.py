"""
URL configuration for inventory_app project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static


from profile.views import profile_view
from admin_profile.views import adminprofile_view
from admin_homepage.views import admin_homepage_view, admin_homepage_view
from admin_login.views import admin_login_view
from student_login.views import student_login_view
from .views import accesspoint_view
from forgotpassword.views import forgotpassword_view


app_name = 'inventory_app'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', accesspoint_view, name='accesspoint'),
    path('profile/', profile_view, name='profile'),
    path('admin_profile/', adminprofile_view, name='admin_profile'),
    path('student_login/', student_login_view, name='student_login'),
    path('admin_login/', admin_login_view, name='admin_login'),
    path('forgotpassword/', forgotpassword_view, name='forgotpassword'),
    path('admin_homepage/', admin_homepage_view, name='admin_homepage'),
    path('accounts/login/', auth_views.LoginView.as_view(), name='login'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)